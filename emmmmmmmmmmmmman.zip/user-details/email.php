<?

$to = "albertpirlo30@gmail.com"; //Change Your Email // To add multiple email use comma ( , )

?>